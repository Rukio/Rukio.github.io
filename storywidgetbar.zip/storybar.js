window.onload = () => {
    const storyUgcsContainer = document.querySelector('.story-list')
    const storyUgcs = document.querySelectorAll('.story-list__item')
    const storyModalWrapper = document.querySelector('.story-modal__wrapper')
    const storyModalClose = document.querySelector('.story-modal-close')
    const storyModalImgs = document.querySelectorAll('.story-modal-img')
    const storyModalList = document.querySelector('.story-modal-list')
    const storyProgressThumb = document.querySelector('.story-modal-progressbar__item')
    const storyModalPurchaseButtons = document.querySelectorAll('.story-modal-purchase')
    const storyModalProductsWrapper = document.querySelector('.story-modal-products__wrapper')
    const autoplayDuration = 4000
    let storyAutoplayInterval = null
    let storyModalItemsLength = storyModalImgs.length
    let storyCurrentSlide = 0
    let storySlideIsDown = false
    let storyUgcsMoved = false
    let storyUgcsIsDown = false
    let storyUgcsStartX
    let storyUgcsScrollLeft

    storyModalList.style.transform = 'translateX(0px)'

    storyUgcs.forEach((item, i) => {
        item.addEventListener('click', () => {
            if (storyUgcsMoved) {
                storyUgcsMoved = false
                return
            }
            storySlideSwitch(i)
            storyModalWrapper.classList.add('story-modal__wrapper_active')
            storyLaunchAutoplay(autoplayDuration)
        })
    })

    storyModalImgs.forEach(item => {
        item.querySelector('.story-modal-img__item').setAttribute('draggable', false)
        item.addEventListener('mousedown', touchDown)
        item.addEventListener('touchdown', touchDown)
        item.addEventListener('mouseup', touchUp)
        item.addEventListener('touchup', touchUp)
        item.addEventListener('mouseleave', () => {
            storySlideIsDown = false
        })
    })

    storyModalPurchaseButtons.forEach(item => {
        item.addEventListener('click', () => {
            storyStopAutoplay()
            showProducts()
        })
    })

    storyModalProductsWrapper.addEventListener('click', function (e) {
        if (e.target.classList.contains('story-modal-products__wrapper')) {
            hideProducts()
        }
    })

    storyModalClose.addEventListener('click', () => {
        storyCloseModal()
    })

    function touchDown() {
        storySlideIsDown = true
        storyStopAutoplay()
    }

    function touchUp(e) {
        if (e.target.classList.contains('story-modal-img__item') && storySlideIsDown) {
            storySlideSwitch('next')
            storyLaunchAutoplay(autoplayDuration)
        }
        storySlideIsDown = false
    }

    function storySlideSwitch(type) {
        const modalListWidth = storyModalList.clientWidth

        if (type === 'next') {
            if (storyCurrentSlide < storyModalItemsLength - 1) {
                storyCurrentSlide++
            } else { storyCurrentSlide = 0 }
            storyModalList.style.transform = `translateX(-${storyCurrentSlide * modalListWidth}px)`
            storyInitProgressbar()
        } else if (typeof type === 'number') {
            if (storyCurrentSlide < storyModalItemsLength - 1 || storyCurrentSlide >= 0) {
                storyCurrentSlide = type
                storyModalList.style.transform = `translateX(-${storyCurrentSlide * modalListWidth}px)`
                storyInitProgressbar()
            }
        }
    }

    function storyLaunchAutoplay(duration) {
        clearInterval(storyAutoplayInterval)
        storyAutoplayInterval = setInterval(() => {
            storySlideSwitch('next')
        }, duration)
    }

    function storyStopAutoplay() {
        clearInterval(storyAutoplayInterval)
    }

    function storyInitProgressbar() {
        storyProgressThumb.setAttribute('style', '');
        requestAnimationFrame(() => {
            requestAnimationFrame(() => {
                storyProgressThumb.setAttribute('style', `transition-duration: ${autoplayDuration}ms`);
                storyProgressThumb.style.transform = `scaleX(1)`
            })
        })
    }

    function storyCloseModal() {
        storyModalWrapper.classList.remove('story-modal__wrapper_active')
        clearInterval(storyAutoplayInterval)
    }

    function hideProducts(e) {
        storyModalProductsWrapper.classList.remove('story-modal-products__wrapper_active')
    }

    function showProducts() {
        storyModalProductsWrapper.classList.add('story-modal-products__wrapper_active')
    }

    storyUgcsContainer.addEventListener('mousedown', (e) => {
        storyUgcsIsDown = true
        storyUgcsMoved = false
        storyUgcsContainer.classList.add('active')
        storyUgcsStartX = e.pageX - storyUgcsContainer.offsetLeft
        storyUgcsScrollLeft = storyUgcsContainer.scrollLeft
    })
    storyUgcsContainer.addEventListener('mouseleave', () => {
        storyUgcsIsDown = false
        storyUgcsContainer.classList.remove('active')
    })
    storyUgcsContainer.addEventListener('mouseup', () => {
        storyUgcsIsDown = false
        storyUgcsContainer.classList.remove('active')
    })
    storyUgcsContainer.addEventListener('mousemove', (e) => {
        if(!storyUgcsIsDown) return
        storyUgcsMoved = true
        console.log(storyUgcsMoved)
        e.preventDefault()
        const x = e.pageX - storyUgcsContainer.offsetLeft
        const walk = (x - storyUgcsStartX) * 3
        storyUgcsContainer.scrollLeft = storyUgcsScrollLeft - walk
    })
}
